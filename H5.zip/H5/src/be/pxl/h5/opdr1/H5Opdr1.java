package be.pxl.h5.opdr1;

public class H5Opdr1 {

	public static void main(String[] args) {

		boolean nightTime = true;
		char letter = 'x';
		byte singleByte = 8;
		short shortNumber = 55;
		int mediumLongNumber = 420;
		double longDecimal = 100 / 3;

		float aMediumLongDecimal = 528.56345F;
		long aLongNumber = 5881555L;
	}
}