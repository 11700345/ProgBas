package be.pxl.h5.opdr4;

public class H5Opdr4 {

	public static void main(String[] args) {
		char number1 = 1;
		char number2 = 2;

		System.out.println(number1 + number2);
		System.out.println(number1 - number2);
		System.out.println(number1 * number2);
		System.out.println(number1 / number2);
		System.out.println(number1 % number2);

	}
}