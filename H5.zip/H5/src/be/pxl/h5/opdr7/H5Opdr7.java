package be.pxl.h5.opdr7;

public class H5Opdr7 {

	public static void main(String[] args) {
		Boolean a = true;
		Boolean b = false;
		
		System.out.println("a\t\t" + a);
		System.out.println("b\t\t" + b);
		System.out.println("a && b\t\t" + (a && b));
		System.out.println("a || b\t\t" + (a || b));
		System.out.println("!a\t\t" + !a);
		System.out.println("!b\t\t" + !b);

	}

}
