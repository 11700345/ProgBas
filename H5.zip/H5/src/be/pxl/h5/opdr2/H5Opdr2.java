package be.pxl.h5.opdr2;

public class H5Opdr2 {

	public static void main(String[] args) {
		final double PI = 3.14;
		PI = 3.15;
	}
}