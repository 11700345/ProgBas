package be.pxl.h5.opdr3;

public class H5Opdr3 {

	public static void main(String[] args) {
		byte aByte;
		short aShortInt = 420;
		aByte = (byte)aShortInt;
		
		System.out.println(aByte);

	}

}
