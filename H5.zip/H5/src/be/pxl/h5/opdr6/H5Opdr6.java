package be.pxl.h5.opdr6;

public class H5Opdr6 {

	public static void main(String[] args) {
		int getal1 = 420;
		int getal2 = 226;
		
		System.out.println("number1 < number2\t: " + (getal1 < getal2));
		System.out.println("number1 > number2\t: " + (getal1 > getal2));
		System.out.println("number1 = number2\t: " + (getal1 == getal2));
		System.out.println("number1 <= number2\t: " + (getal1 <= getal2));
		System.out.println("number1 >= number2\t: " + (getal1 >= getal2));

	}
}