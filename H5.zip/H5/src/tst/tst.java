package tst;

import java.util.Scanner;

public class tst {

	public static void main(String[] args) {
		int x =3;
		
		switch (x) {
			case 1:
				System.out.println("1");
				break;
			case (2):
				System.out.println("2 of 3");
				break;
			case (3):
				System.out.println("2 of 3");
				break;
			default:
				System.out.println("niet 123");
				break;
				
		}

	}

}
